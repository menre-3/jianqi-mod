package cn.meng.jianqi;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;
import net.minecraftforge.common.util.EnumHelper;

public class GreenSword extends ItemSword {

    private static final Item.ToolMaterial GREEN_MATERIAL =
            EnumHelper.addToolMaterial("green_sword", 3, 200, 7.0F, 2.0F, 14);

    public GreenSword() {
        super(GREEN_MATERIAL);
        this.setMaxDamage(200);
        this.setUnlocalizedName("green_sword");
        this.setRegistryName("green_sword");
        this.setCreativeTab(CreativeTabs.COMBAT);
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (!stack.isEmpty() && stack.getItem() instanceof GreenSword) {
            if (!world.isRemote) {
                boolean active = !stack.getOrCreateCompound().getBoolean("shieldActive");
                stack.getOrCreateCompound().setBoolean("shieldActive", active);
            }
            return new ActionResult<ItemStack>(EnumActionResult.SUCCESS, stack);
        }
        return super.onItemRightClick(world, player, hand);
    }
}