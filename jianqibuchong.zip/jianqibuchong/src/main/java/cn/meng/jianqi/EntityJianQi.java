package cn.meng.jianqi;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;

public class EntityJianQi extends Entity {

    private static final double SPEED = 1.2D;
    private static final double MAX_RANGE = 16.0D;
    private static final double DAMAGE = 10.0F;
    private static final double HIT_LENGTH = 2.0D;

    private EntityLivingBase owner;
    private double traveled = 0;

    public EntityJianQi(World world) {
        super(world);
        this.setSize(0.5F, 0.5F);
    }

    public EntityJianQi(World world, EntityLivingBase owner) {
        this(world);
        this.owner = owner;
        Vec3d look = owner.getLookVec();
        this.setPosition(
                owner.posX + look.x * 1.0D,
                owner.posY + owner.getEyeHeight() + look.y * 1.0D - 0.1D,
                owner.posZ + look.z * 1.0D);
        this.motionX = look.x * SPEED;
        this.motionY = look.y * SPEED;
        this.motionZ = look.z * SPEED;
        this.rotationYaw = owner.rotationYaw;
        this.rotationPitch = owner.rotationPitch;
    }

    @Override
    protected void entityInit() {}

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.world.isRemote) {
            this.move(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
            this.spawnParticles();
            return;
        }
        double prevX = this.posX, prevY = this.posY, prevZ = this.posZ;
        this.move(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
        double moved = Math.sqrt(Math.pow(this.posX - prevX, 2)
                + Math.pow(this.posY - prevY, 2)
                + Math.pow(this.posZ - prevZ, 2));
        this.traveled += moved;
        if (this.traveled >= MAX_RANGE || moved < 0.01D) {
            this.setDead();
            return;
        }
        this.checkHits();
    }

    private void checkHits() {
        Vec3d dir = new Vec3d(this.motionX, this.motionY, this.motionZ).normalize();
        AxisAlignedBB aabb = this.getEntityBoundingBox().grow(0.5D);
        AxisAlignedBB scanBox = aabb.offset(dir.x * HIT_LENGTH, dir.y * HIT_LENGTH, dir.z * HIT_LENGTH).union(aabb);

        List<? extends Entity> list = this.world.getEntitiesInAABBexcluding(this, scanBox, null);
        for (Entity e : list) {
            if (e == this.owner || !(e instanceof EntityLivingBase)) continue;
            e.attackEntityFrom(DamageSource.causeIndirectDamage(this, this.owner), (float) DAMAGE);
            this.setDead();
            return;
        }
    }

    // 月牙弧光，不拖尾成块
    private void spawnParticles() {
        this.world.spawnParticle(EnumParticleTypes.SWEEP_ATTACK,
                this.posX, this.posY, this.posZ,
                0.0D, 0.0D, 0.0D);
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound compound) {}

    @Override
    protected void writeEntityToNBT(NBTTagCompound compound) {}
}