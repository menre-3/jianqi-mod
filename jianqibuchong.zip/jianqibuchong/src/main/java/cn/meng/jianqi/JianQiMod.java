package cn.meng.jianqi;

import cn.meng.jianqi.client.RenderJianQi;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryManager;

@Mod(modid = JianQiMod.MODID, name = JianQiMod.NAME, version = JianQiMod.VERSION, acceptedMinecraftVersions = "[1.12.2]")
public class JianQiMod {

    public static final String MODID = "jianqi";
    public static final String NAME = "Jian Qi";
    public static final String VERSION = "1.0.0";

    public static EnchantmentJianQi enchantmentJianQi;
    public static GreenSword greenSword;

    @Mod.Instance(MODID)
    public static JianQiMod instance;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        // 注册附魔
        enchantmentJianQi = new EnchantmentJianQi();
        enchantmentJianQi.setRegistryName(MODID, "jian_qi");
        IForgeRegistry<Enchantment> enchantmentRegistry = RegistryManager.ACTIVE.getRegistry(Enchantment.class);
        enchantmentRegistry.register(enchantmentJianQi);

        // 注册剑气实体
        EntityRegistry.registerModEntity(
                new ResourceLocation(MODID, "jian_qi"),
                EntityJianQi.class,
                "jian_qi",
                0,
                instance,
                64,
                1,
                true);

        // 注册绿剑
        greenSword = new GreenSword();
        GameRegistry.registerItem(greenSword, "green_sword");

        MinecraftForge.EVENT_BUS.register(this);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        if (event.getSide().isClient()) {
            RenderingRegistry.registerEntityRenderingHandler(EntityJianQi.class, RenderJianQi::new);
        }
    }

    // 剑气附魔：右键释放月牙剑气
    @SubscribeEvent
    public void onRightClick(PlayerInteractEvent.RightClickItem event) {
        EntityPlayer player = event.getEntityPlayer();
        if (player == null || player.world.isRemote) return;
        ItemStack stack = event.getItemStack();
        if (stack.isEmpty() || !(stack.getItem() instanceof ItemSword)) return;
        if (EnchantmentHelper.getEnchantmentLevel(enchantmentJianQi, stack) <= 0) return;

        stack.damageItem(3, player);
        EntityJianQi jianQi = new EntityJianQi(player.world, player);
        player.world.spawnEntity(jianQi);
    }

    // 绿剑护盾：手持绿剑且开盾 → 隔绝伤害，扣耐久 = 伤害×20%
    @SubscribeEvent
    public void onLivingHurt(LivingHurtEvent event) {
        if (!(event.getEntityLiving() instanceof EntityPlayer)) return;
        EntityPlayer player = (EntityPlayer) event.getEntityLiving();
        ItemStack stack = player.getHeldItemMainhand();
        if (!stack.isEmpty() && stack.getItem() instanceof GreenSword) {
            if (stack.getOrCreateCompound().getBoolean("shieldActive")) {
                event.setCanceled(true);
                int dmg = Math.max(1, (int) (event.getAmount() * 0.2F));
                stack.damageItem(dmg, player);
            }
        }
    }
}