package cn.meng.jianqi.client;

import cn.meng.jianqi.GreenSword;
import cn.meng.jianqi.JianQiMod;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumParticleTypes;
import net.minecraftforge.client.event.ColorHandlerEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
@Mod.EventBusSubscriber(value = Side.CLIENT)
public class ClientShieldParticles {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null) return;
        ItemStack stack = mc.player.getHeldItemMainhand();
        if (!stack.isEmpty() && stack.getItem() instanceof GreenSword) {
            if (GreenSword.getShieldTag(stack).getBoolean("shieldActive")) {
                spawnShield(mc);
            }
        }
    }

    private static void spawnShield(Minecraft mc) {
        double py = mc.player.posY + 1.0D;
        double yaw = Math.toRadians(mc.player.rotationYaw);
        for (int i = 0; i <= 8; i++) {
            double angle = yaw + Math.PI * (i / 8.0) - Math.PI / 2.0;
            double dx = Math.sin(angle) * 2.5D;
            double dz = Math.cos(angle) * 2.5D;
            mc.world.spawnParticle(EnumParticleTypes.SWEEP_ATTACK,
                    mc.player.posX + dx, py, mc.player.posZ + dz,
                    0.0D, 0.0D, 0.0D);
        }
    }

    @SubscribeEvent
    public static void onItemColor(ColorHandlerEvent.Item event) {
        event.getItemColors().registerItemColorHandler(
                (stack, tint) -> 0x33FF33, JianQiMod.greenSword);
    }
}