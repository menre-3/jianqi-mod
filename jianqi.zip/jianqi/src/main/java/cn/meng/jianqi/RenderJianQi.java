package cn.meng.jianqi.client;

import cn.meng.jianqi.EntityJianQi;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class RenderJianQi extends Render<EntityJianQi> {

    public RenderJianQi(RenderManager renderManager) {
        super(renderManager);
    }

    @Override
    public void doRender(EntityJianQi entity, double x, double y, double z,
                         float entityYaw, float partialTicks) {
        // 剑气本体由白色粒子呈现，这里不渲染任何模型
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityJianQi entity) {
        return null;
    }
}