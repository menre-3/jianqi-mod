package cn.meng.jianqi;

import cn.meng.jianqi.client.RenderJianQi;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod(modid = JianQiMod.MODID, name = JianQiMod.NAME, version = JianQiMod.VERSION, acceptedMinecraftVersions = "[1.12.2]")
public class JianQiMod {

    public static final String MODID = "jianqi";
    public static final String NAME = "Jian Qi";
    public static final String VERSION = "1.0.0";

    public static EnchantmentJianQi enchantmentJianQi;

    @Mod.Instance(MODID)
    public static JianQiMod instance;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        // 注册附魔
        enchantmentJianQi = new EnchantmentJianQi();
        GameRegistry.registerEnchantment(enchantmentJianQi);
        // 注册剑气实体（64格追踪，每tick同步位置）
        GameRegistry.registerEntity(EntityJianQi.class, "jian_qi", 0, instance, 64, 1, true);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        // 客户端绑定渲染器
        if (event.getSide().isClient()) {
            ClientRegistry.bindEntityRenderHandler(EntityJianQi.class, RenderJianQi::new);
        }
    }

    /** 右键：手持剑 + 有剑气附魔 → 释放剑气，扣3耐久，无冷却 */
    @SubscribeEvent
    public void onRightClick(PlayerInteractEvent.RightClickItem event) {
        EntityPlayer player = event.getEntityPlayer();
        if (player == null || player.world.isRemote) return; // 只在服务端处理
        ItemStack stack = event.getItemStack();
        if (stack.isEmpty() || !(stack.getItem() instanceof ItemSword)) return;
        if (EnchantmentHelper.getEnchantmentLevel(enchantmentJianQi, stack) <= 0) return;

        stack.damageItem(3, player); // 消耗3点耐久
        EntityJianQi jianQi = new EntityJianQi(player.world, player);
        player.world.spawnEntity(jianQi);
    }
}