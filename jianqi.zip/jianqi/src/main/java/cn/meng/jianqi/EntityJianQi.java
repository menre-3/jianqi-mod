package cn.meng.jianqi;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;

public class EntityJianQi extends Entity {

    private static final double SPEED = 1.2D;      // 飞行速度：格/秒 的1/20
    private static final double MAX_RANGE = 16.0D; // 持续16格后消失
    private static final double DAMAGE = 10.0F;    // 伤害：10点 = 5颗心
    private static final double HIT_LENGTH = 2.0D; // 剑气命中范围：前方2格长

    private EntityLivingBase owner;
    private double traveled = 0; // 已飞行距离

    public EntityJianQi(World world) {
        super(world);
        this.setSize(0.5F, 0.5F);
    }

    public EntityJianQi(World world, EntityLivingBase owner) {
        this(world);
        this.owner = owner;
        // 出生在玩家眼睛前方1格，避免卡在玩家体内
        Vec3d look = owner.getLookVec();
        this.setPosition(
                owner.posX + look.x * 1.0D,
                owner.posY + owner.getEyeHeight() + look.y * 1.0D - 0.1D,
                owner.posZ + look.z * 1.0D);
        this.motionX = look.x * SPEED;
        this.motionY = look.y * SPEED;
        this.motionZ = look.z * SPEED;
        this.rotationYaw = owner.rotationYaw;
        this.rotationPitch = owner.rotationPitch;
    }

    @Override
    protected void entityInit() {}

    @Override
    public void onUpdate() {
        super.onUpdate();

        if (this.world.isRemote) {
            // ===== 客户端：只管移动 + 白色粒子 =====
            this.move(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
            this.spawnParticles();
            return;
        }

        // ===== 服务端：移动 + 碰撞 + 伤害 =====
        double prevX = this.posX, prevY = this.posY, prevZ = this.posZ;
        this.move(MoverType.SELF, this.motionX, this.motionY, this.motionZ);

        double moved = Math.sqrt(Math.pow(this.posX - prevX, 2)
                + Math.pow(this.posY - prevY, 2)
                + Math.pow(this.posZ - prevZ, 2));
        this.traveled += moved;

        // 飞满16格 或 被方块卡住 → 消失
        if (this.traveled >= MAX_RANGE || moved < 0.01D) {
            this.setDead();
            return;
        }
        this.checkHits();
    }

    /** 检测前方2格范围内的生物，命中造成伤害 */
    private void checkHits() {
        Vec3d dir = new Vec3d(this.motionX, this.motionY, this.motionZ).normalize();
        AxisAlignedBB aabb = this.getEntityBoundingBox().grow(0.5D);
        // 从当前位置沿飞行方向延伸2格
        AxisAlignedBB scanBox = aabb.offset(dir.x * HIT_LENGTH, dir.y * HIT_LENGTH, dir.z * HIT_LENGTH).union(aabb);

        List<Entity> list = this.world.getEntitiesInAABBexcluding(this, scanBox, null);
        for (Entity e : list) {
            if (e == this.owner || !(e instanceof EntityLivingBase)) continue;
            e.attackEntityFrom(DamageSource.causeIndirectDamage(this, this.owner), (float) DAMAGE);
            this.setDead(); // 命中即消失
            return;
        }
    }

    /** 客户端：白色剑气粒子 */
    private void spawnParticles() {
        for (int i = 0; i < 4; i++) {
            double dx = (this.rand.nextDouble() - 0.5D) * 0.15D;
            double dy = (this.rand.nextDouble() - 0.5D) * 0.15D;
            double dz = (this.rand.nextDouble() - 0.5D) * 0.15D;
            this.world.spawnParticle(EnumParticleTypes.END_ROD,
                    this.posX + (this.rand.nextDouble() - 0.5D) * 0.3D,
                    this.posY + (this.rand.nextDouble() - 0.5D) * 0.3D,
                    this.posZ + (this.rand.nextDouble() - 0.5D) * 0.3D,
                    dx, dy, dz);
        }
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound compound) {}

    @Override
    protected void writeEntityToNBT(NBTTagCompound compound) {}
}