package cn.meng.jianqi;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;

public class EnchantmentJianQi extends Enchantment {

    public EnchantmentJianQi() {
        super(Rarity.UNCOMMON, EnumEnchantmentType.WEAPON,
                new EntityEquipmentSlot[]{EntityEquipmentSlot.MAINHAND});
        setName("jianqi.jian_qi");
    }

    @Override
    public int getMinEnchantability(int level) { return 15; }
    @Override
    public int getMaxEnchantability(int level) { return 60; }
    @Override
    public int getMaxLevel() { return 1; }

    @Override
    public boolean canApply(ItemStack stack) {
        return stack.getItem() instanceof ItemSword && super.canApply(stack);
    }
}