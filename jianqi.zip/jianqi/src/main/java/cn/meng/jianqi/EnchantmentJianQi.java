package cn.meng.jianqi;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;

public class EnchantmentJianQi extends Enchantment {

    public EnchantmentJianQi() {
        // 稀有度、类型（武器）、可附魔槽位（主手）
        super(Rarity.UNCOMMON, EnumEnchantmentType.WEAPON,
                new EntityEquipmentSlot[]{EntityEquipmentSlot.MAINHAND});
        setRegistryName("jian_qi");
        setName("jianqi.jian_qi"); // 语言文件 key：enchantment.jianqi.jian_qi
    }

    @Override
    public int getMinEnchantability(int level) { return 15; } // 附魔台最低15级
    @Override
    public int getMaxEnchantability(int level) { return 60; }
    @Override
    public int getMaxLevel() { return 1; }

    // 只允许附在剑上（原版剑+大部分模组剑都继承 ItemSword）
    @Override
    public boolean canApply(ItemStack stack) {
        return stack.getItem() instanceof ItemSword && super.canApply(stack);
    }
}